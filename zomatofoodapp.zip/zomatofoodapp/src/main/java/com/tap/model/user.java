package com.tap.model;

import java.sql.Timestamp;

public class user {
 int userid;
 String name;
 String username;
 String password;
 
 String phonenumber;
 
 String role;
 Timestamp createdate;
 Timestamp lastlogindate;
 public user(){ 
 }


public user(String name, String username, String password, String phonenumber, String role) {
	super();
	this.name = name;
	this.username = username;
	this.password = password;
	this.phonenumber = phonenumber;
	this.role = role;
}
//this constructor is used when ever we want to create user object with all parameters
public user(int userid, String name, String username, 
		String password, String phonenumber, String role,
		Timestamp createdate, Timestamp lastlogindate) {
	super();
	this.userid = userid;
	this.name = name;
	this.username = username;
	this.password = password;
	this.phonenumber = phonenumber;
	this.role = role;
	this.createdate = createdate;
	this.lastlogindate = lastlogindate;
}


public int getUserid() {
	return userid;
}
public void setUserid(int userid) {
	this.userid = userid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

public String getPhonenumber() {
	return phonenumber;
}
public void setPhonenumber(String phonenumber) {
	this.phonenumber = phonenumber;
}


public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public Timestamp getCreatedate() {
	return createdate;
}
public void setCreatedate(Timestamp createdate) {
	this.createdate = createdate;
}
public Timestamp getLastlogindate() {
	return lastlogindate;
}
public void setLastlogindate(Timestamp lastlogindate) {
	this.lastlogindate = lastlogindate;
}
//@Override
public String toString() {
	return "user: ["+name+" "+username+" "+password+" "+"]";
}
 
 
}
