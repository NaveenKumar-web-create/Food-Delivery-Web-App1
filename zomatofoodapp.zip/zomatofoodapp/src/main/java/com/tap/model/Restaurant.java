package com.tap.model;

public class Restaurant {
	private int restaurantId;
	private String name;
	private String cuisine;
	private double rating;
	private String imageUrl;
	private int deliveryTime;
	private boolean isActive;
	private int adminUserId;
	public Restaurant() {
		
	}
	public Restaurant(int restaurantId, String name, String cuisine, double rating, String imageUrl, int deliveryTime,
			boolean isActive, int adminUserId) {
		super();
		this.restaurantId = restaurantId;
		this.name = name;
		this.cuisine = cuisine;
		this.rating = rating;
		this.imageUrl = imageUrl;
		this.deliveryTime = deliveryTime;
		this.isActive = isActive;
		this.adminUserId = adminUserId;
	}
	public int getRestaurantId() {
		return restaurantId;
	}
	public void setRestaurantId(int restaurantId) {
		this.restaurantId = restaurantId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCuisine() {
		return cuisine;
	}
	public void setCuisine(String cuisine) {
		this.cuisine = cuisine;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public int getDeliveryTime() {
		return deliveryTime;
	}
	public void setDeliveryTime(int deliveryTime) {
		this.deliveryTime = deliveryTime;
	}
	public boolean isActive() {
		return isActive;
	}
	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}
	public int getAdminUserId() {
		return adminUserId;
	}
	public void setAdminUserId(int adminUserId) {
		this.adminUserId = adminUserId;
	}
	@Override
	public String toString() {
		return "Restaurant [restaurantId=" + restaurantId + ", name=" + name + ", cuisine=" + cuisine + ", rating="
				+ rating + ", imageUrl=" + imageUrl + ", deliveryTime=" + deliveryTime + ", isActive=" + isActive
				+ ", adminUserId=" + adminUserId + "]";
	}
	
	
}
