package com.tap.model;

import com.tap.model.Menu;

public class OrderItem {
	private int orderitemId;
	private int orderId;
	private int menuId;
	private int quantity;
	private double itemTotal;
	private Menu menuItem;//optional for maintaining relation
	public OrderItem() {
		
	}
	public OrderItem(int orderitemId, int orderId, int menuId, int quantity, double itemTotal) {
		super();
		this.orderitemId = orderitemId;
		this.orderId = orderId;
		this.menuId = menuId;
		this.quantity = quantity;
		this.itemTotal = itemTotal;
	}
	public int getOrderitemId() {
		return orderitemId;
	}
	public void setOrderitemId(int orderitemId) {
		this.orderitemId = orderitemId;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getMenuId() {
		return menuId;
	}
	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getItemTotal() {
		return itemTotal;
	}
	public void setItemTotal(double itemTotal) {
		this.itemTotal = itemTotal;
	}
	@Override
	public String toString() {
		return "OrderItem [orderitemId=" + orderitemId + ", orderId=" + orderId + ", menuId=" + menuId + ", quantity="
				+ quantity + ", itemTotal=" + itemTotal + ", menuItem=" + menuItem + "]";
	}
	
	
	

}
