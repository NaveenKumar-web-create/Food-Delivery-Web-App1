package com.tap.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBconnection {
	private static String url="jdbc:mysql://localhost:3306/foodapp";
	private static String username="root";
	private static  String password="Nandhuyvp4@";
	private static  Connection connection;
	public static Connection getConnection()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			 connection=	DriverManager.getConnection(url,username,password);
			
			} catch (SQLException e) {
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		//we have to return connection after try catch
		return connection;
	}
}
