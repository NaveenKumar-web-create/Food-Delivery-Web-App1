package com.tap.DAOImpl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.tap.DAO.OrderHistoryDAO;
import com.tap.model.OrderHistory;
import com.tap.util.DBconnection;

public class OrderHistoryDAOImpl implements OrderHistoryDAO {

    private static final String INSERT_SQL =
        "INSERT INTO orderhistory (orderId, userId, totalAmount, orderDate, orderStatus) VALUES (?, ?, ?, ?, ?)";

    private static final String SELECT_BY_USER_SQL =
        "SELECT * FROM orderhistory WHERE userId = ? ORDER BY orderDate DESC";

    @Override
    public void addOrderHistory(OrderHistory orderHistory) {
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setInt(1, orderHistory.getOrderId());
            ps.setInt(2, orderHistory.getUserId());
            ps.setDouble(3, orderHistory.getTotalAmount());
            ps.setTimestamp(4, orderHistory.getOrderDate());
            ps.setString(5, orderHistory.getOrderStatus());
            ps.executeUpdate();

            System.out.println("✅ OrderHistory added for orderId: " + orderHistory.getOrderId());

        } catch (SQLException e) {
            System.err.println("❌ SQL Error in addOrderHistory: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public List<OrderHistory> getOrderHistoriesByuser(int userId) {
        List<OrderHistory> histories = new ArrayList<>();

        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_BY_USER_SQL)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                OrderHistory history = new OrderHistory();
                history.setHistoryId(rs.getInt("historyId"));
                history.setOrderId(rs.getInt("orderId"));
                history.setUserId(rs.getInt("userId"));
                history.setTotalAmount(rs.getDouble("totalAmount"));
                history.setOrderDate(rs.getTimestamp("orderDate"));
                history.setOrderStatus(rs.getString("orderStatus"));
                histories.add(history);
            }

        } catch (SQLException e) {
            System.err.println("❌ SQL Error in getOrderHistoriesByuser: " + e.getMessage());
            e.printStackTrace();
        }

        return histories;
    }
}
