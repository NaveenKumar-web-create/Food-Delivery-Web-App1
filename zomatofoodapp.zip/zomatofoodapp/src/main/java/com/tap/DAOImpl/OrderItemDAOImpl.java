package com.tap.DAOImpl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.tap.DAO.OrderItemDAO;
import com.tap.model.OrderItem;
import com.tap.util.DBconnection;

public class OrderItemDAOImpl implements OrderItemDAO {

    private static final String INSERT_SQL =
        "INSERT INTO order_item (order_id, menu_id, quantity, item_total) VALUES (?, ?, ?, ?)";

    private static final String SELECT_BY_ID_SQL =
        "SELECT * FROM order_item WHERE order_item_id = ?";

    private static final String UPDATE_SQL =
        "UPDATE order_item SET order_id = ?, menu_id = ?, quantity = ?, item_total = ? WHERE order_item_id = ?";

    private static final String DELETE_SQL =
        "DELETE FROM order_item WHERE order_item_id = ?";

    private static final String SELECT_BY_ORDER_SQL =
        "SELECT * FROM order_item WHERE order_id = ?";

    // ✅ Add new OrderItem
    @Override
    public void addOrderItem(OrderItem orderItem) {
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {

            ps.setInt(1, orderItem.getOrderId());
            ps.setInt(2, orderItem.getMenuId());
            ps.setInt(3, orderItem.getQuantity());
            ps.setDouble(4, orderItem.getItemTotal());

            ps.executeUpdate();
            System.out.println("✅ OrderItem added successfully!");

        } catch (SQLException e) {
            System.err.println("❌ Error adding OrderItem: " + e.getMessage());
        }
    }

    // ✅ Retrieve an OrderItem by ID
    @Override
    public OrderItem getOrderItem(int orderItemId) {
        OrderItem orderItem = null;

        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_BY_ID_SQL)) {

            ps.setInt(1, orderItemId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                orderItem = new OrderItem();
                orderItem.setOrderitemId(rs.getInt("order_item_id"));
                orderItem.setOrderId(rs.getInt("order_id"));
                orderItem.setMenuId(rs.getInt("menu_id"));
                orderItem.setQuantity(rs.getInt("quantity"));
                orderItem.setItemTotal(rs.getDouble("item_total"));
            }

        } catch (SQLException e) {
            System.err.println("❌ Error retrieving OrderItem: " + e.getMessage());
        }

        return orderItem;
    }

    // ✅ Update an OrderItem
    @Override
    public void updateOrderItem(OrderItem orderItem) {
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setInt(1, orderItem.getOrderId());
            ps.setInt(2, orderItem.getMenuId());
            ps.setInt(3, orderItem.getQuantity());
            ps.setDouble(4, orderItem.getItemTotal());
            ps.setInt(5, orderItem.getOrderitemId());

            ps.executeUpdate();
            System.out.println("✅ OrderItem updated successfully!");

        } catch (SQLException e) {
            System.err.println("❌ Error updating OrderItem: " + e.getMessage());
        }
    }

    // ✅ Delete an OrderItem by ID
    @Override
    public void deleteOrderItem(int orderItemId) {
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setInt(1, orderItemId);
            ps.executeUpdate();
            System.out.println("🗑️ OrderItem deleted successfully!");

        } catch (SQLException e) {
            System.err.println("❌ Error deleting OrderItem: " + e.getMessage());
        }
    }

    // ✅ Retrieve all OrderItems by Order ID
    @Override
    public List<OrderItem> getOrderItemsByOrderId(int orderId) {
        List<OrderItem> orderItems = new ArrayList<>();

        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_BY_ORDER_SQL)) {

            ps.setInt(1, orderId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                OrderItem orderItem = new OrderItem();
                orderItem.setOrderitemId(rs.getInt("order_item_id"));
                orderItem.setOrderId(rs.getInt("order_id"));
                orderItem.setMenuId(rs.getInt("menu_id"));
                orderItem.setQuantity(rs.getInt("quantity"));
                orderItem.setItemTotal(rs.getDouble("item_total"));
                orderItems.add(orderItem);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error retrieving OrderItems for order ID " + orderId + ": " + e.getMessage());
        }

        return orderItems;
    }
}
