package com.tap.DAOImpl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.tap.DAO.RestaurantDAO;
import com.tap.model.Restaurant;
import com.tap.util.DBconnection;

public class RestaurantDAOImpl implements RestaurantDAO {

    private static final String INSERT_SQL =
        "INSERT INTO restaurant (name, cuisine, rating, imageUrl, deliveryTime, isActive, adminUserId) VALUES (?, ?, ?, ?, ?, ?, ?)";

    private static final String SELECT_BY_ID_SQL =
        "SELECT * FROM restaurant WHERE restaurantId = ?";

    private static final String SELECT_ALL_SQL =
        "SELECT * FROM restaurant";

    private static final String UPDATE_SQL =
        "UPDATE restaurant SET name = ?, cuisine = ?, rating = ?, imageUrl = ?, deliveryTime = ?, isActive = ?, adminUserId = ? WHERE restaurantId = ?";

    private static final String DELETE_SQL =
        "DELETE FROM restaurant WHERE restaurantId = ?";

    @Override
    public void addRestaurant(Restaurant restaurant) {
        try (Connection connection = DBconnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(INSERT_SQL)) {

            ps.setString(1, restaurant.getName());
            ps.setString(2, restaurant.getCuisine());
            ps.setDouble(3, restaurant.getRating());
            ps.setString(4, restaurant.getImageUrl());
            ps.setInt(5, restaurant.getDeliveryTime());
            ps.setBoolean(6, restaurant.isActive());
            ps.setInt(7, restaurant.getAdminUserId());

            int result = ps.executeUpdate();
            System.out.println(result + " Restaurant added successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Restaurant getRestaurant(int restaurantId) {
        Restaurant restaurant = null;

        try (Connection connection = DBconnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(SELECT_BY_ID_SQL)) {

            ps.setInt(1, restaurantId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                restaurant = new Restaurant(
                    rs.getInt("restaurantId"),
                    rs.getString("name"),
                    rs.getString("cuisine"),
                    rs.getDouble("rating"),
                    rs.getString("imageUrl"),
                    rs.getInt("deliveryTime"),
                    rs.getBoolean("isActive"),
                    rs.getInt("adminUserId")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return restaurant;
    }

    @Override
    public void updateRestaurant(Restaurant restaurant) {
        try (Connection connection = DBconnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(UPDATE_SQL)) {

            ps.setString(1, restaurant.getName());
            ps.setString(2, restaurant.getCuisine());
            ps.setDouble(3, restaurant.getRating());
            ps.setString(4, restaurant.getImageUrl());
            ps.setInt(5, restaurant.getDeliveryTime());
            ps.setBoolean(6, restaurant.isActive());
            ps.setInt(7, restaurant.getAdminUserId());
            ps.setInt(8, restaurant.getRestaurantId());

            int result = ps.executeUpdate();
            System.out.println(result + " Restaurant updated successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteRestaurant(int restaurantId) {
        try (Connection connection = DBconnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(DELETE_SQL)) {

            ps.setInt(1, restaurantId);
            int result = ps.executeUpdate();
            System.out.println(result + " Restaurant deleted successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Restaurant> getAllRestaurants() {
        List<Restaurant> restaurants = new ArrayList<>();

        try (Connection connection = DBconnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(SELECT_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Restaurant restaurant = new Restaurant(
                    rs.getInt("restaurantId"),
                    rs.getString("name"),
                    rs.getString("cuisine"),
                    rs.getDouble("rating"),
                    rs.getString("imageUrl"),
                    rs.getInt("deliveryTime"),
                    rs.getBoolean("isActive"),
                    rs.getInt("adminUserId")
                );
                restaurants.add(restaurant);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return restaurants;
    }
}
