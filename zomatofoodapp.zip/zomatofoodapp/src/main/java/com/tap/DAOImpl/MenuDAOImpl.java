package com.tap.DAOImpl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.tap.DAO.MenuDAO;
import com.tap.model.Menu;
import com.tap.util.DBconnection;

public class MenuDAOImpl implements MenuDAO {

    private static final String INSERT_SQL =
        "INSERT INTO menu (restaurantId, itemName, price, description, imageUrl, isAvailable) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String SELECT_BY_ID_SQL =
        "SELECT * FROM menu WHERE menuId = ?";
    private static final String UPDATE_SQL =
        "UPDATE menu SET restaurantId = ?, itemName = ?, price = ?, description = ?, imageUrl = ?, isAvailable = ? WHERE menuId = ?";
    private static final String DELETE_SQL =
        "DELETE FROM menu WHERE menuId = ?";
    private static final String SELECT_BY_RESTAURANT_SQL =
        "SELECT * FROM menu WHERE restaurantId = ?";

    @Override
    public void addMenu(Menu menu) {
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL)) {
            ps.setInt(1, menu.getRestaurantId());
            ps.setString(2, menu.getItemName());
            ps.setDouble(3, menu.getPrice());
            ps.setString(4, menu.getDescription());
            ps.setString(5, menu.getImageurl());
            ps.setBoolean(6, menu.isAvailable());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error adding menu: " + e.getMessage());
        }
    }

    @Override
    public Menu getMenu(int menuId) {
        Menu menu = null;
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_BY_ID_SQL)) {
            ps.setInt(1, menuId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                menu = new Menu();
                menu.setMenuId(rs.getInt("menuId"));
                menu.setRestaurantId(rs.getInt("restaurantId"));
                menu.setItemName(rs.getString("itemName"));
                menu.setPrice(rs.getDouble("price"));
                menu.setDescription(rs.getString("description"));
                menu.setImageurl(rs.getString("imageUrl"));
                menu.setAvailable(rs.getBoolean("isAvailable"));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching menu: " + e.getMessage());
        }
        return menu;
    }

    @Override
    public void updateMenu(Menu menu) {
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {
            ps.setInt(1, menu.getRestaurantId());
            ps.setString(2, menu.getItemName());
            ps.setDouble(3, menu.getPrice());
            ps.setString(4, menu.getDescription());
            ps.setString(5, menu.getImageurl());
            ps.setBoolean(6, menu.isAvailable());
            ps.setInt(7, menu.getMenuId());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error updating menu: " + e.getMessage());
        }
    }

    @Override
    public void deleteMenu(int menuId) {
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {
            ps.setInt(1, menuId);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error deleting menu: " + e.getMessage());
        }
    }

    @Override
    public List<Menu> getMenusByRestaurant(int restaurantId) {
        List<Menu> menuList = new ArrayList<>();
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_BY_RESTAURANT_SQL)) {
            ps.setInt(1, restaurantId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Menu menu = new Menu();
                menu.setMenuId(rs.getInt("menuId"));
                menu.setRestaurantId(rs.getInt("restaurantId"));
                menu.setItemName(rs.getString("itemName"));
                menu.setPrice(rs.getDouble("price"));
                menu.setDescription(rs.getString("description"));
                menu.setImageurl(rs.getString("imageUrl"));
                menu.setAvailable(rs.getBoolean("isAvailable"));
                menuList.add(menu);
            }
            System.out.println("✅ Loaded " + menuList.size() + " menu items for restaurant ID: " + restaurantId);
        } catch (SQLException e) {
            System.err.println("Error fetching menus by restaurant: " + e.getMessage());
        }
        return menuList;
    }
}
