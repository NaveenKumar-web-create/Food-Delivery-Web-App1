package com.tap.DAOImpl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.tap.DAO.OrderDAO;
import com.tap.model.Order;
import com.tap.util.DBconnection;

public class OrderDAOImpl implements OrderDAO {

    // ✅ SQL Queries (escaped `order` keyword)
    private static final String INSERT_SQL =
        "INSERT INTO `order` (userId, restaurantId, totalAmount, status, paymentMethod, orderDate, address) VALUES (?, ?, ?, ?, ?, NOW(), ?)";

    private static final String SELECT_BY_ID_SQL =
        "SELECT * FROM `order` WHERE orderId = ?";

    private static final String SELECT_BY_USER_SQL =
        "SELECT * FROM `order` WHERE userId = ? ORDER BY orderDate DESC";

    private static final String UPDATE_SQL =
        "UPDATE `order` SET totalAmount = ?, status = ?, paymentMethod = ?, address = ? WHERE orderId = ?";

    private static final String DELETE_SQL =
        "DELETE FROM `order` WHERE orderId = ?";

    // ✅ Add a new order
    @Override
    public void addOrder(Order order) {
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT_SQL, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, order.getUserId());
            ps.setInt(2, order.getRestaurantId());
            ps.setDouble(3, order.getTotalAmount());
            ps.setString(4, order.getStatus());
            ps.setString(5, order.getPaymentMethod());
            ps.setString(6, order.getAddress());

            int rows = ps.executeUpdate();

            if (rows > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        order.setOrderId(rs.getInt(1));
                    }
                }
            }

            System.out.println("✅ Order inserted successfully for userId: " + order.getUserId());

        } catch (SQLException e) {
            System.err.println("❌ Error inserting order: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ✅ Get order by ID
    @Override
    public Order getOrder(int orderId) {
        Order order = null;

        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_BY_ID_SQL)) {

            ps.setInt(1, orderId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                order = mapResultSetToOrder(rs);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error fetching order: " + e.getMessage());
            e.printStackTrace();
        }

        return order;
    }

    // ✅ Update an existing order
    @Override
    public void updateOrder(Order order) {
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(UPDATE_SQL)) {

            ps.setDouble(1, order.getTotalAmount());
            ps.setString(2, order.getStatus());
            ps.setString(3, order.getPaymentMethod());
            ps.setString(4, order.getAddress());
            ps.setInt(5, order.getOrderId());

            ps.executeUpdate();
            System.out.println("✅ Order updated successfully (ID: " + order.getOrderId() + ")");

        } catch (SQLException e) {
            System.err.println("❌ Error updating order: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ✅ Delete an order
    @Override
    public void deleteOrder(int orderId) {
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(DELETE_SQL)) {

            ps.setInt(1, orderId);
            ps.executeUpdate();
            System.out.println("🗑️ Order deleted successfully (ID: " + orderId + ")");

        } catch (SQLException e) {
            System.err.println("❌ Error deleting order: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ✅ Get all orders by a specific user
    @Override
    public List<Order> getAllOrdersByuser(int userId) {
        List<Order> orders = new ArrayList<>();

        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_BY_USER_SQL)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                orders.add(mapResultSetToOrder(rs));
            }

            System.out.println("✅ Retrieved " + orders.size() + " orders for userId: " + userId);

        } catch (SQLException e) {
            System.err.println("❌ Error fetching orders: " + e.getMessage());
            e.printStackTrace();
        }

        return orders;
    }

    // ✅ Update only the status (for cancel/deliver)
    @Override
    public void updateOrderStatus(int orderId, String newStatus) {
        String sql = "UPDATE `order` SET status = ? WHERE orderId = ?";

        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, newStatus);
            ps.setInt(2, orderId);
            ps.executeUpdate();

            System.out.println("🔄 Order ID " + orderId + " status updated to: " + newStatus);

        } catch (SQLException e) {
            System.err.println("❌ Error updating order status: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // ✅ Helper method to map ResultSet → Order object
    private Order mapResultSetToOrder(ResultSet rs) throws SQLException {
        Order order = new Order();
        order.setOrderId(rs.getInt("orderId"));
        order.setUserId(rs.getInt("userId"));
        order.setRestaurantId(rs.getInt("restaurantId"));
        order.setTotalAmount(rs.getDouble("totalAmount"));
        order.setStatus(rs.getString("status"));
        order.setPaymentMethod(rs.getString("paymentMethod"));
        order.setAddress(rs.getString("address"));
        order.setOrderDate(rs.getTimestamp("orderDate"));
        return order;
    }
}
