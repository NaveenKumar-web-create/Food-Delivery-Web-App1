package com.tap.DAOImpl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.tap.DAO.userDAO;
import com.tap.model.user;
import com.tap.util.DBconnection;

public class userDAOImpl implements userDAO {

    // ✅ SQL Queries
    private static final String INSERT_SQL =
        "INSERT INTO user (name, username, password, phonenumber, role, createdate, lastlogindate) VALUES (?, ?, ?, ?, ?, NOW(), NOW())";

    private static final String UPDATE_SQL =
        "UPDATE user SET name = ?, username = ?, password = ?, phonenumber = ?, role = ? WHERE userId = ?";

    private static final String SELECT_BY_ID_SQL =
        "SELECT * FROM user WHERE userId = ?";

    private static final String SELECT_ALL_SQL =
        "SELECT * FROM user";

    private static final String DELETE_SQL =
        "DELETE FROM user WHERE userId = ?";

    private static final String LOGIN_SQL =
        "SELECT * FROM user WHERE username = ? AND password = ?";

    // ✅ Fetch all users
    @Override
    public List<user> getAllUsers() {
        List<user> users = new ArrayList<>();

        try (Connection connection = DBconnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(SELECT_ALL_SQL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                user u = new user(
                    rs.getInt("userId"),
                    rs.getString("name"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("phonenumber"),
                    rs.getString("role"),
                    rs.getTimestamp("createdate"),
                    rs.getTimestamp("lastlogindate")
                );
                users.add(u);
            }

            System.out.println("✅ Fetched " + users.size() + " users from database.");

        } catch (SQLException e) {
            System.err.println("❌ Error fetching users: " + e.getMessage());
        }

        return users;
    }

    // ✅ Fetch user by ID
    @Override
    public user getuserByid(int userId) {
        user u = null;

        try (Connection connection = DBconnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(SELECT_BY_ID_SQL)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                u = new user(
                    rs.getInt("userId"),
                    rs.getString("name"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("phonenumber"),
                    rs.getString("role"),
                    rs.getTimestamp("createdate"),
                    rs.getTimestamp("lastlogindate")
                );
            }

        } catch (SQLException e) {
            System.err.println("❌ Error fetching user by ID: " + e.getMessage());
        }

        return u;
    }

    // ✅ Add new user (used in RegisterServlet)
    @Override
    public void adduser(user u) {
        try (Connection connection = DBconnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(INSERT_SQL)) {

            ps.setString(1, u.getName());
            ps.setString(2, u.getUsername());
            ps.setString(3, u.getPassword());
            ps.setString(4, u.getPhonenumber());
            ps.setString(5, u.getRole());

            int result = ps.executeUpdate();
            System.out.println("✅ User added successfully (" + result + " row inserted).");

        } catch (SQLException e) {
            System.err.println("❌ Error adding user: " + e.getMessage());
        }
    }

    // ✅ Update user details
    @Override
    public void updateuser(user u) {
        try (Connection connection = DBconnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(UPDATE_SQL)) {

            ps.setString(1, u.getName());
            ps.setString(2, u.getUsername());
            ps.setString(3, u.getPassword());
            ps.setString(4, u.getPhonenumber());
            ps.setString(5, u.getRole());
            ps.setInt(6, u.getUserid());

            int result = ps.executeUpdate();
            if (result > 0) {
                System.out.println("✅ User updated successfully (ID: " + u.getUserid() + ")");
            } else {
                System.out.println("⚠️ No user found with ID: " + u.getUserid());
            }

        } catch (SQLException e) {
            System.err.println("❌ Error updating user: " + e.getMessage());
        }
    }

    // ✅ Delete user by ID
    @Override
    public void deleteuser(int userId) {
        try (Connection connection = DBconnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(DELETE_SQL)) {

            ps.setInt(1, userId);
            int result = ps.executeUpdate();

            if (result > 0) {
                System.out.println("🗑️ User deleted successfully (ID: " + userId + ")");
            } else {
                System.out.println("⚠️ No user found to delete (ID: " + userId + ")");
            }

        } catch (SQLException e) {
            System.err.println("❌ Error deleting user: " + e.getMessage());
        }
    }
    @Override
    public user getUserByCredentials(String username, String password) {
        user u = null;
        String SQL = "SELECT * FROM user WHERE username = ? AND password = ?";
        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL)) {

            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                u = new user();
                u.setUserid(rs.getInt("userId"));
                u.setName(rs.getString("name"));
                u.setUsername(rs.getString("username"));
                u.setPassword(rs.getString("password"));
                u.setPhonenumber(rs.getString("phonenumber"));
                u.setRole(rs.getString("role"));
                u.setCreatedate(rs.getTimestamp("createdate"));
                u.setLastlogindate(rs.getTimestamp("lastlogindate"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return u;
    }
    @Override
    public boolean isUsernameExists(String username) {
        boolean exists = false;
        String SQL = "SELECT COUNT(*) FROM user WHERE username = ?";

        try (Connection conn = DBconnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL)) {

            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                exists = rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exists;
    }



    // ✅ Verify login credentials (used in LoginServlet)
    public user getuserByUsernameAndPassword(String username, String password) {
        user u = null;

        try (Connection connection = DBconnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(LOGIN_SQL)) {

            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                u = new user(
                    rs.getInt("userId"),
                    rs.getString("name"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("phonenumber"),
                    rs.getString("role"),
                    rs.getTimestamp("createdate"),
                    rs.getTimestamp("lastlogindate")
                );
                System.out.println("✅ Login successful for user: " + username);
            } else {
                System.out.println("⚠️ Invalid credentials for username: " + username);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error during login check: " + e.getMessage());
        }

        return u;
    }
}
