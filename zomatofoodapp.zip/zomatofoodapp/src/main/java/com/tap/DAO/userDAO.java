package com.tap.DAO;

import java.util.List;

import com.tap.model.user;

public interface userDAO {
	List<user> getAllUsers();
	user getuserByid(int userid);
	void adduser (user u);
	void updateuser(user u);
	void deleteuser(int userid);
	user getUserByCredentials(String username, String password);
	boolean isUsernameExists(String username);


}
