package com.tap.Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.tap.model.Cart;
import com.tap.model.CartItem;
import com.tap.model.Menu;
import com.tap.DAO.MenuDAO;
import com.tap.DAOImpl.MenuDAOImpl;

@WebServlet("/cart")
public class CartServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();
        Cart cart = (Cart) session.getAttribute("cart");

        // ✅ If cart is null, create one
        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }

        String action = req.getParameter("action");
        if (action == null || action.isEmpty()) {
            action = "view"; // default
        }

        switch (action) {
            case "view":
                req.getRequestDispatcher("cart.jsp").forward(req, resp);
                break;

            case "remove":
                try {
                    int itemIdToRemove = Integer.parseInt(req.getParameter("itemId"));
                    cart.removeItem(itemIdToRemove);
                } catch (Exception e) {
                    e.printStackTrace();
                    session.setAttribute("cartError", "Error removing item. Please try again.");
                }
                resp.sendRedirect("cart?action=view");
                break;

            case "clear":
                cart.clear();
                session.removeAttribute("restaurantId"); // clear restaurant link
                resp.sendRedirect("cart?action=view");
                break;

            default:
                resp.sendRedirect("menu.jsp");
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }

        String action = req.getParameter("action");
        if (action == null) action = "add";

        try {
            switch (action) {
                case "add":
                    addItemToCart(req, session, cart, resp);
                    return; // handled inside
                case "update":
                    updateCartItem(req, cart);
                    break;
                case "remove":
                    removeItemFromCart(req, cart);
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("cartError", "⚠️ Something went wrong while processing your request.");
        }

        // ✅ Always redirect after POST (never leave blank screen)
        resp.sendRedirect("cart?action=view");
    }

    /**
     * ✅ Add item to cart (handles restaurant consistency)
     */
    private void addItemToCart(HttpServletRequest req, HttpSession session, Cart cart, HttpServletResponse resp)
            throws IOException {
        try {
            // ✅ Parse parameters safely
            String itemParam = req.getParameter("itemId");
            String qtyParam = req.getParameter("quantity");
            String restParam = req.getParameter("restaurantId");

            if (itemParam == null || qtyParam == null || restParam == null) {
                session.setAttribute("cartError", "Invalid item data. Please try again.");
                resp.sendRedirect("cart?action=view");
                return;
            }

            int itemId = Integer.parseInt(itemParam);
            int quantity = Integer.parseInt(qtyParam);
            int newRestaurantId = Integer.parseInt(restParam);

            System.out.println("🛒 Adding item → itemId=" + itemId + ", qty=" + quantity + ", restId=" + newRestaurantId);

            MenuDAO menuDAO = new MenuDAOImpl();
            Menu menuItem = menuDAO.getMenu(itemId);

            if (menuItem == null) {
                session.setAttribute("cartError", "Item not found. Please try again.");
                resp.sendRedirect("cart?action=view");
                return;
            }

            // ✅ Check if user tries to mix restaurants
            Integer currentRestaurantId = (Integer) session.getAttribute("restaurantId");
            if (currentRestaurantId != null && currentRestaurantId != newRestaurantId) {
                session.setAttribute("cartError",
                        "Your cart contains items from another restaurant. Please clear your cart first.");
                resp.sendRedirect("cart?action=view");
                return;
            }

            // ✅ Add item normally
            CartItem item = new CartItem(
                    menuItem.getMenuId(),
                    menuItem.getRestaurantId(),
                    menuItem.getItemName(),
                    menuItem.getPrice(),
                    quantity
            );

            cart.addItem(item);
            session.setAttribute("restaurantId", menuItem.getRestaurantId());
            session.removeAttribute("cartError"); // clear any old error

            // ✅ Always redirect after adding item
            resp.sendRedirect("cart?action=view");

        } catch (NumberFormatException e) {
            e.printStackTrace();
            session.setAttribute("cartError", "Invalid input. Please try again.");
            resp.sendRedirect("cart?action=view");
        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("cartError", "Unexpected error while adding item.");
            resp.sendRedirect("cart?action=view");
        }
    }

    private void updateCartItem(HttpServletRequest req, Cart cart) {
        try {
            int itemId = Integer.parseInt(req.getParameter("itemId"));
            int quantity = Integer.parseInt(req.getParameter("quantity"));
            cart.updateItem(itemId, quantity);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void removeItemFromCart(HttpServletRequest req, Cart cart) {
        try {
            int itemId = Integer.parseInt(req.getParameter("itemId"));
            cart.removeItem(itemId);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
