package com.tap.Servlet;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.tap.DAOImpl.OrderDAOImpl;
import com.tap.model.Order;

@WebServlet("/trackorder")
public class TrackOrderServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String orderIdParam = req.getParameter("orderId");
        if (orderIdParam == null || orderIdParam.isEmpty()) {
            resp.getWriter().println("<h3 style='color:red;text-align:center;'>Invalid Order ID!</h3>");
            return;
        }

        try {
            int orderId = Integer.parseInt(orderIdParam);

            OrderDAOImpl orderDAO = new OrderDAOImpl();
            Order order = orderDAO.getOrder(orderId);

            if (order != null) {
                req.setAttribute("order", order);
                RequestDispatcher rd = req.getRequestDispatcher("trackorder.jsp");
                rd.forward(req, resp);
            } else {
                resp.getWriter().println("<h3 style='color:red;text-align:center;'>Order not found!</h3>");
            }

        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().println("<h3 style='color:red;text-align:center;'>Error tracking order!</h3>");
        }
    }
}
