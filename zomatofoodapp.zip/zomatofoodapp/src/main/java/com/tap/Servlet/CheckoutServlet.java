package com.tap.Servlet;

import java.io.IOException;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.tap.model.*;
import com.tap.util.DBconnection;

@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();

        Cart cart = (Cart) session.getAttribute("cart");
        Integer userId = (Integer) session.getAttribute("userId");
        Integer restaurantId = (Integer) session.getAttribute("restaurantId");

        String paymentMethod = req.getParameter("paymentMethod");
        String address = req.getParameter("address");

        if (cart == null || cart.getItems().isEmpty()) {
            resp.getWriter().println("<h3 style='color:red;text-align:center;'>Your cart is empty!</h3>");
            return;
        }

        if (userId == null || restaurantId == null) {
            resp.getWriter().println("<h3 style='color:red;text-align:center;'>Session expired. Please log in again.</h3>");
            return;
        }

        double totalAmount = cart.getTotalPrice();
        int orderId = 0;

        try (Connection conn = DBconnection.getConnection()) {
            conn.setAutoCommit(false);

            // ✅ Correct table and column names
            String insertOrderSQL =
                "INSERT INTO `order` (userId, restaurantId, totalAmount, status, paymentMethod, orderDate, Address) " +
                "VALUES (?, ?, ?, ?, ?, NOW(), ?)";
            PreparedStatement psOrder = conn.prepareStatement(insertOrderSQL, Statement.RETURN_GENERATED_KEYS);
            psOrder.setInt(1, userId);
            psOrder.setInt(2, restaurantId);
            psOrder.setDouble(3, totalAmount);
            psOrder.setString(4, "Order Confirmed");
            psOrder.setString(5, paymentMethod);
            psOrder.setString(6, address);

            int affectedRows = psOrder.executeUpdate();

            if (affectedRows == 0) {
                throw new SQLException("⚠ Order insertion failed, no rows affected.");
            }

            ResultSet rs = psOrder.getGeneratedKeys();
            if (rs.next()) {
                orderId = rs.getInt(1);
            } else {
                throw new SQLException("⚠ Failed to retrieve generated order ID.");
            }

            // ✅ Insert into orderitem (table name and columns must exist)
            String insertItemSQL = "INSERT INTO orderitem (orderId, menuId, quantity, itemTotal) VALUES (?, ?, ?, ?)";
            PreparedStatement psItem = conn.prepareStatement(insertItemSQL);
            for (CartItem item : cart.getItems().values()) {
                psItem.setInt(1, orderId);
                psItem.setInt(2, item.getMenuId());
                psItem.setInt(3, item.getQuantity());
                psItem.setDouble(4, item.getPrice() * item.getQuantity());
                psItem.addBatch();
            }
            psItem.executeBatch();

            // ✅ Insert into orderhistory (ensure these columns exist)
            String insertHistorySQL =
                "INSERT INTO orderhistory (orderId, userId, totalAmount, orderDate, orderStatus) VALUES (?, ?, ?, NOW(), ?)";
            PreparedStatement psHist = conn.prepareStatement(insertHistorySQL);
            psHist.setInt(1, orderId);
            psHist.setInt(2, userId);
            psHist.setDouble(3, totalAmount);
            psHist.setString(4, "Order Confirmed");
            psHist.executeUpdate();

            conn.commit();

            // ✅ Clear cart and save order ID in session
            session.removeAttribute("cart");
            session.setAttribute("lastOrderId", orderId);

            // Redirect to My Orders
            resp.sendRedirect("orderSuccess.jsp");


        } catch (SQLException e) {
            e.printStackTrace();
            resp.getWriter().println("<h3 style='color:red;text-align:center;'>Error processing order: " + e.getMessage() + "</h3>");
        }
    }
}
