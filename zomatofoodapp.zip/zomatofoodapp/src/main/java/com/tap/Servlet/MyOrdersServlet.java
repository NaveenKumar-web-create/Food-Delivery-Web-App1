package com.tap.Servlet;

import java.io.IOException;
import java.util.List;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.tap.DAO.OrderDAO;
import com.tap.DAO.OrderHistoryDAO;
import com.tap.DAOImpl.OrderDAOImpl;
import com.tap.DAOImpl.OrderHistoryDAOImpl;
import com.tap.model.Order;
import com.tap.model.OrderHistory;

@WebServlet("/myorders")
public class MyOrdersServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();
        Integer userId = (Integer) session.getAttribute("userId");

        if (userId == null) {
            resp.sendRedirect("login.jsp");
            return;
        }

        OrderDAO orderDAO = new OrderDAOImpl();
        OrderHistoryDAO historyDAO = new OrderHistoryDAOImpl();

        List<Order> orders = orderDAO.getAllOrdersByuser(userId);
        List<OrderHistory> history = historyDAO.getOrderHistoriesByuser(userId);

        req.setAttribute("orders", orders);
        req.setAttribute("history", history);

        RequestDispatcher rd = req.getRequestDispatcher("myorders.jsp");
        rd.forward(req, resp);
    }
}
