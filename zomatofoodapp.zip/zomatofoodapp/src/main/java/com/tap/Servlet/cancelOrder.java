package com.tap.Servlet;

import java.io.IOException;
import java.sql.Timestamp;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.tap.DAO.OrderDAO;
import com.tap.DAO.OrderHistoryDAO;
import com.tap.DAOImpl.OrderDAOImpl;
import com.tap.DAOImpl.OrderHistoryDAOImpl;
import com.tap.model.Order;
import com.tap.model.OrderHistory;

@WebServlet("/cancelOrder")
public class cancelOrder extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();

        try {
            String orderIdParam = req.getParameter("orderId");
            if (orderIdParam == null || orderIdParam.isEmpty()) {
                session.setAttribute("msg", "⚠️ Invalid order ID!");
                resp.sendRedirect("myorders");
                return;
            }

            int orderId = Integer.parseInt(orderIdParam);
            System.out.println("🟢 CancelOrderServlet triggered for Order ID: " + orderId);

            OrderDAO orderDAO = new OrderDAOImpl();
            OrderHistoryDAO historyDAO = new OrderHistoryDAOImpl();

            // ✅ 1️⃣ Fetch existing order
            Order order = orderDAO.getOrder(orderId);

            if (order == null) {
                System.err.println("❌ No order found for ID: " + orderId);
                session.setAttribute("msg", "⚠️ Order not found!");
                resp.sendRedirect("myorders");
                return;
            }

            System.out.println("✅ Order found: " + order.getOrderId() + " | Status: " + order.getStatus());

            // ✅ 2️⃣ Update order status
            orderDAO.updateOrderStatus(orderId, "Cancelled");
            System.out.println("🔄 Order status updated to 'Cancelled' in DB.");

            // ✅ 3️⃣ Add to order history
            OrderHistory history = new OrderHistory();
            history.setOrderId(order.getOrderId());
            history.setUserId(order.getUserId());
            history.setTotalAmount(order.getTotalAmount());
            history.setOrderDate(new Timestamp(System.currentTimeMillis()));
            history.setOrderStatus("Cancelled");

            historyDAO.addOrderHistory(history);
            System.out.println("🟢 OrderHistory entry added successfully.");

            // ✅ 4️⃣ Send success message
            session.setAttribute("msg", "❌ Order #" + orderId + " cancelled successfully!");
            resp.sendRedirect("myorders");

        } catch (NumberFormatException e) {
            e.printStackTrace();
            session.setAttribute("msg", "⚠️ Invalid order ID format!");
            resp.sendRedirect("myorders");

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("❌ Exception in CancelOrderServlet: " + e.getMessage());
            session.setAttribute("msg", "⚠️ Something went wrong while cancelling your order!");
            resp.sendRedirect("myorders");
        }
    }
}
