package com.tap.Servlet;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.tap.DAO.userDAO;
import com.tap.DAOImpl.userDAOImpl;
import com.tap.model.user;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String username = req.getParameter("username");
        String password = req.getParameter("password");

        userDAO dao = new userDAOImpl();
        user existingUser = dao.getUserByCredentials(username, password);

        if (existingUser != null) {
            // ✅ Login success
            HttpSession session = req.getSession();
            session.setAttribute("userId", existingUser.getUserid());
            session.setAttribute("username", existingUser.getUsername());

            resp.sendRedirect("home");
        } else {
            // ❌ User not found → redirect to registration
            req.setAttribute("error", "User not found! Please register.");
            RequestDispatcher rd = req.getRequestDispatcher("register.jsp");
            rd.forward(req, resp);
        }
    }
}
