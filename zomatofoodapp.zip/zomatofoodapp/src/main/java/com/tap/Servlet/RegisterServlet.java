package com.tap.Servlet;

import java.io.IOException;
import java.sql.Timestamp;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.tap.DAO.userDAO;
import com.tap.DAOImpl.userDAOImpl;
import com.tap.model.user;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String name = req.getParameter("name");
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String phonenumber = req.getParameter("phonenumber");

        userDAO dao = new userDAOImpl();

        // ✅ 1. Check if username already exists
        if (dao.isUsernameExists(username)) {
            req.setAttribute("error", "Username already exists! Please try another.");
            RequestDispatcher rd = req.getRequestDispatcher("register.jsp");
            rd.forward(req, resp);
            return;
        }

        // ✅ 2. Otherwise, register the user
        user newUser = new user();
        newUser.setName(name);
        newUser.setUsername(username);
        newUser.setPassword(password);
        newUser.setPhonenumber(phonenumber);
        newUser.setRole("customer");
        newUser.setCreatedate(new Timestamp(System.currentTimeMillis()));
        newUser.setLastlogindate(new Timestamp(System.currentTimeMillis()));

        dao.adduser(newUser);

        req.setAttribute("success", "Registration successful! Please login.");
        RequestDispatcher rd = req.getRequestDispatcher("login.jsp");
        rd.forward(req, resp);
    }
}
