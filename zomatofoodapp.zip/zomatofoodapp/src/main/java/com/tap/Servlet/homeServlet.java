package com.tap.Servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.tap.DAO.RestaurantDAO;
import com.tap.DAOImpl.RestaurantDAOImpl;
import com.tap.model.Restaurant;

@WebServlet("/home")
public class homeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("text/html;charset=UTF-8");

        try {
            // ✅ Fetch all restaurants
            RestaurantDAO restaurantDAO = new RestaurantDAOImpl();
            List<Restaurant> restaurantList = restaurantDAO.getAllRestaurants();

            // ✅ Set the data as a request attribute
            req.setAttribute("restaurants", restaurantList);

            // ✅ Debugging log
            System.out.println("✅ Loaded " + restaurantList.size() + " restaurants from database.");

            // ✅ Forward to home.jsp
            RequestDispatcher rd = req.getRequestDispatcher("home.jsp");
            rd.forward(req, resp);

        } catch (Exception e) {
            System.err.println("❌ Error loading restaurants: " + e.getMessage());
            e.printStackTrace();

            req.setAttribute("errorMessage", "Unable to load restaurants. Please try again later.");
            RequestDispatcher rd = req.getRequestDispatcher("error.jsp");
            rd.forward(req, resp);
        }
    }
}
