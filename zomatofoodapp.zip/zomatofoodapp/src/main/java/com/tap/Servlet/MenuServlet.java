package com.tap.Servlet;

import java.io.IOException;
import java.util.List;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.tap.DAO.MenuDAO;
import com.tap.DAOImpl.MenuDAOImpl;
import com.tap.model.Menu;

@WebServlet("/menu")
public class MenuServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String restaurantIdParam = req.getParameter("restaurantId");

        if (restaurantIdParam == null || restaurantIdParam.isEmpty()) {
            resp.getWriter().println("<h3 style='color:red;'>No restaurant selected!</h3>");
            return;
        }

        try {
            int restaurantId = Integer.parseInt(restaurantIdParam);

            // ✅ Store restaurantId in session (used later in checkout)
            HttpSession session = req.getSession();
            session.setAttribute("restaurantId", restaurantId);

            MenuDAO menuDAO = new MenuDAOImpl();
            List<Menu> menuList = menuDAO.getMenusByRestaurant(restaurantId);

            req.setAttribute("menus", menuList);
            req.setAttribute("restaurantId", restaurantId);

            RequestDispatcher rd = req.getRequestDispatcher("menu.jsp");
            rd.forward(req, resp);

        } catch (NumberFormatException e) {
            resp.getWriter().println("<h3 style='color:red;'>Invalid restaurant ID!</h3>");
            e.printStackTrace();
        }
    }
}
