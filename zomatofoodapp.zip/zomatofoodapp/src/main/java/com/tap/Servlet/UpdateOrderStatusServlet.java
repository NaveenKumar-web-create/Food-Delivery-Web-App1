package com.tap.Servlet;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.tap.DAO.OrderDAO;
import com.tap.DAOImpl.OrderDAOImpl;

@WebServlet("/updateOrderStatus")
public class UpdateOrderStatusServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String orderIdParam = req.getParameter("orderId");
        String newStatus = req.getParameter("status");

        if (orderIdParam == null || newStatus == null || orderIdParam.isEmpty() || newStatus.isEmpty()) {
            resp.getWriter().println("<h3 style='color:red;text-align:center;'>Invalid Request!</h3>");
            return;
        }

        try {
            int orderId = Integer.parseInt(orderIdParam);

            OrderDAO orderDAO = new OrderDAOImpl();
            orderDAO.updateOrderStatus(orderId, newStatus);  // ✅ Call DAO method

            resp.sendRedirect("myorders"); // go back to orders page

        } catch (Exception e) {
            e.printStackTrace();
            resp.getWriter().println("<h3 style='color:red;text-align:center;'>Error updating order status!</h3>");
        }
    }
}
